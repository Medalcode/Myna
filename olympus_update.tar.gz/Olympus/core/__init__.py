"""Olympus Core Module"""
from .database import db

__all__ = ['db']
