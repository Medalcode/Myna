"""Hermes Worker - Faucet Bot"""
from .worker import HermesWorker

__all__ = ['HermesWorker']
