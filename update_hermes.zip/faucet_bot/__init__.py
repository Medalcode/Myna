
# Este archivo permite que Python trate el directorio faucet_bot como un paquete
# Se mantiene vacío intencionalmente o con importaciones mínimas
